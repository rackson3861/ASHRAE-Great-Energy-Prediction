from MICE import MiceImputer 
import pandas as pd
import matplotlib.pyplot as plt
z = MiceImputer()

dtrain = pd.read_csv('weather_test.csv')   ## import weather_test to do the imputing again

plt.hist(dtrain['wind_direction'])                # check various plots one by one
plt.show()

dtrain['air_temperature'] = dtrain['air_temperature'].interpolate()

dtrain['dew_temperature'] = dtrain['dew_temperature'].interpolate()

dtrain['cloud_coverage'] =  dtrain['cloud_coverage'].interpolate()   

dtrain['precip_depth_1_hr'] = dtrain['precip_depth_1_hr'].interpolate()

dtrain['sea_level_pressure'] = dtrain['sea_level_pressure'].interpolate()

dtrain['wind_direction'] = dtrain['wind_direction'].interpolate()

dtrain['wind_speed'] = dtrain['wind_speed'].interpolate()

dtrain.isnull().sum()

dtrain['precip_depth_1_hr'].fillna(value = 0,inplace = True)

dtrain.isnull().sum()

#dtrain.iloc[:,2:9] = z.fit_transform(dtrain.iloc[:,2:9])  To use MICE imputation

correlation = dtrain.iloc[:,2:9].corr()
import seaborn as sns
import matplotlib.pyplot as plt
sns.heatmap(correlation, cmap = 'RdYlGn',annot = True)
plt.show()


dtrain.to_csv('weather_test1.csv',index = False)