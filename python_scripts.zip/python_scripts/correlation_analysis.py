import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Read in the csv files.
df1 = pd.read_csv('building_metadata.csv')
df2 = pd.read_csv('weather_train.csv')
df3 = pd.read_csv('train.csv')

df1_site11 = df1[df1['site_id']==11]
df2_site11 = df2[df2['site_id']==11]
df3_site11 = df3[df3['building_id']>1027]
df3_site11 = df3_site11[df3_site11['building_id']<1033]
df4 = pd.merge(df1_site11, df2_site11, on=['site_id'])

df5 = pd.merge(df4, df3_site11, on=['timestamp'])

df5.drop(['site_id','building_id_x','year_built','floor_count','cloud_coverage','precip_depth_1_hr'],axis = 1,inplace = True)

time_stamp = [0]
cnt = 0
for i in range(df5.shape[0]-1):
    if df5.iloc[i,2]==df5.iloc[i+1,2]:
        time_stamp.append(cnt)
    else:
        cnt=cnt+1
        time_stamp.append(cnt)
        
time_stamp = pd.DataFrame(time_stamp)

df5 = pd.concat([df5,time_stamp],axis=1)
df5.drop(['timestamp'],axis=1,inplace = True)

correlation = df2.corr()
plt.figure(figsize=(12,6))
sns.heatmap(correlation,annot=True)

plt.show()


correlation = df1.corr()
sns.heatmap(correlation,annot=True,cmap = 'RdYlGn')
plt.show()

build = df5.iloc[:,7:8].values
meter = df5.iloc[:,8:9].values
use = df5.iloc[:,0:1].values


labelencoder = LabelEncoder()

build[:,0] = labelencoder.fit_transform(build[:, 0])
use[:, 0] = labelencoder.fit_transform(use[:, 0])            # ENCODING CATEGORICAL
meter[:,0]= labelencoder.fit_transform(meter[:, 0])

onehotencoder = OneHotEncoder(categorical_features = [0])

build = onehotencoder.fit_transform(build).toarray()
use = onehotencoder.fit_transform(use).toarray()
meter = onehotencoder.fit_transform(meter).toarray()
build = build[1:,:]
use = use[1:,:]
meter = meter[1:,:]

build = pd.DataFrame(build)
use = pd.DataFrame(use)
meter = pd.DataFrame(meter)
df5.drop(['building_id_y','primary_use','meter'],axis=1,inplace = True)

df5 = pd.concat([df5,build,use,meter],axis=1)

pf = df5.head()

X = df5
y = df5['meter_reading']
X.drop(['meter_reading'],axis=1,inplace = True)

X = X.values
y = y.values
X = X[:,1:3]
y = y.reshape(-1,1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42)

sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)
y_test = sc_y.transform(y_test)

from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout

NN_model = Sequential()

# The Input Layer :
NN_model.add(Dense(8, kernel_initializer='normal',input_dim = X_train.shape[1], activation='relu'))

# The Hidden Layers :
NN_model.add(Dense(8, kernel_initializer='normal',activation='relu'))
NN_model.add(Dense(8, kernel_initializer='normal',activation='relu'))
NN_model.add(Dense(8, kernel_initializer='normal',activation='relu'))

# The Output Layer :
NN_model.add(Dense(1, kernel_initializer='normal',activation='linear'))

NN_model.compile(loss='mean_absolute_error', optimizer='adam', metrics=['mse'])
model_summary =  NN_model.summary()
NN_model.fit(X_train,y_train, epochs = 200,batch_size = 64,validation_data = (X_test,y_test))



