from MICE import MiceImputer 
import pandas as pd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import matplotlib.pyplot as plt
z = MiceImputer()

dp = pd.read_csv('building_metadata.csv')

#imputing year_built

year = dp['year_built'].dropna()
count = 0
for i in range(dp.shape[0]):     # run two times
    if(count<year.shape[0]):
        if(str(dp.iloc[i,4])=='nan'):
            dp.iloc[i,4] = year.iloc[count]
            count=count+1
    

floor = dp['floor_count'].dropna()
count = 0
for i in range(dp.shape[0]):      # run 4 times
    if(count<floor.shape[0]):
        if(str(dp.iloc[i,5])=='nan'):
            dp.iloc[i,5] = floor.iloc[count]
            count=count+1
    
plt.hist(dp['floor_count'])
plt.show()
plt.hist(dp['year_built'])
plt.show()

dp.isnull().sum()

correlation1 = dp.corr()
import seaborn as sns
import matplotlib.pyplot as plt
sns.heatmap(correlation, cmap = 'RdYlGn',annot = True)
plt.show()

dp = pd.concat([p,q],axis=1)

dp.to_csv('building_metadata1.csv',index = False)